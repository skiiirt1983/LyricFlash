LyricFlash case - print pack

lyricflash_print_plates.3mf: one Bambu Studio project, one plate per print:
  1 top shell (filament 1, Iridium Gold PLA Metal), face-down
  2 base - ribbed, 3 base - panels, 4 base - smooth (filament 2, black PETG): print ONE of the three
  5 the two latch clips (filament 2, PETG: they flex)
stl/: the same parts as separate STLs, already in print orientation.

Base: supports off, except paint a support enforcer on the top edge of the USB-C opening.
Everything else: supports off. 0.2 mm layers, 4 walls, 15 % gyroid.
Assembly steps and what to check: PHASE2_CHECKLIST.md.
