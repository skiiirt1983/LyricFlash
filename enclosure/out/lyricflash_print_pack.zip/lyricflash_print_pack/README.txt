LyricFlash case - print pack

lyricflash_print_plates.3mf: one Bambu Studio project, one plate per print
(if it opens as a single plate, use the files in 3mf_per_plate/ instead):
  1 top shell (filament 1, Iridium Gold PLA Metal), face-down
  2-4 base with the cable cleat on the back: ribbed, panels, smooth
  5-7 the same bases without the cleat (filament 2, black PETG): print ONE of the six bases
  8 the carrier plate the board screws to (filament 2, black PETG)
Hardware: 3x M2 x 3 flat head (board to plate), 3x M2.5 x 6 pan head (plate to base, self-tapping, no nuts),
8x 4 x 2 mm disc magnets (4 in the base corners, 4 in the shell; check they attract before pressing in).
Cable: one turn round the cleat on the back takes any pull off the USB-C plug.
stl/: the same parts as separate STLs, already in print orientation.

Base: supports off, except paint a support enforcer on the top edge of the USB-C opening.
Everything else: supports off. 0.2 mm layers, 4 walls, 15 % gyroid.
Assembly steps and what to check: PHASE2_CHECKLIST.md.
