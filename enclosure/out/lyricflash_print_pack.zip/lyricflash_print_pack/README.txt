LyricFlash case - print pack

lyricflash_print_plates.3mf: one Bambu Studio project, one plate per print
lyricflash_print_plates_PLA.3mf: the same with the six PLA bases
Both carry Paul's Bambu settings and the hand-painted USB-C supports (tree supports, manual). The PETG file also has his
easy-removal support settings (top Z 0.26, 3 interface layers, skirt); the PLA file has those three reset to Bambu's defaults.
In the PLA file pick a PLA profile for filament slot 2 (it is still set to PETG Matte).
  1 top shell (filament 1, Iridium Gold PLA Metal), face-down
  2-4 base with the cable cleat on the back: ribbed, panels, smooth
  5-7 the same bases without the cleat (filament 2, black PETG): print ONE of the six bases
  8 the carrier plate the board screws to (filament 2, black PETG)
Hardware: 3x M2 x 3 flat head (board to plate), 2x M2.5 x 6 pan head (plate to base, self-tapping, no nuts),
8x 4 x 2 mm disc magnets (4 in the base corners, 4 in the shell; check they attract before pressing in).
Cable: one turn round the cleat on the back takes any pull off the USB-C plug.
stl/: the same parts as separate STLs, already in print orientation.

PLA bases: stl_pla/ holds the same six bases for PLA. Only the base magnet pockets differ
(dia 4.20 instead of 4.10, from the C11 coupon). Print with X-Y hole compensation 0. Print ONE of the six. The top
shell and the carrier plate are the same for both (the PLA profile reuses stl/carrier_plate.stl).

Supports: only where painted at the USB-C opening of the bases (already done in the projects). 0.2 mm layers, 4 walls (Arachne), gyroid.
Assembly steps and what to check: PHASE2_CHECKLIST.md.
